'use strict';
const BootBot = require('./lib/BootBot');

module.exports = BootBot;
